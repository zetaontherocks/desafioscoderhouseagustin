let veces = prompt('Ingrese un numero');

for (let i = 1; i <= veces; i++) {
	alert('Hola Coder');
}
