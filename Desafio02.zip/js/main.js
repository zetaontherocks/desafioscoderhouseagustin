let numero = prompt('Ingresar un numero');
let a = parseInt(numero);

if (a >= 10 && a <= 50) {
	alert('numero correcto');
}
